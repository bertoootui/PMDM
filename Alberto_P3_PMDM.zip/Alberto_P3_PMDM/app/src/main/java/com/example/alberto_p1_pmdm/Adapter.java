package com.example.alberto_p1_pmdm;

import android.content.Context;
import android.content.Intent;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collection;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolderDatos> implements View.OnLongClickListener {


    Entrenamiento entrenamiento = new Entrenamiento();
    ArrayList<Entrenamiento> listaEntrenamiento;
    private View.OnLongClickListener listener;

    public Adapter(ArrayList<Entrenamiento> listaEntrenamiento) {
        this.listaEntrenamiento = listaEntrenamiento;
    }



    
    @NonNull
    @Override
    public Adapter.ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_layout, parent, false);
        view.setOnLongClickListener(this);


        return new ViewHolderDatos(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolderDatos holder, final int position) {

            //holder.mDistancia.setText(listaEntrenamiento.get(position).toString());
            double distancia = listaEntrenamiento.get(position).getDistancia();
            double tiempo = listaEntrenamiento.get(position).getTiempo();
            String poss = String.valueOf(position);
            holder.txtId.setText(poss);


    }

    @Override
    public int getItemCount() {
        return listaEntrenamiento.size();
    }

    @Override
    public boolean onLongClick(View v) {
        if(listener!=null)
        {
            listener.onLongClick(v);
        }



        return false;
    }

    public static class ViewHolderDatos extends RecyclerView.ViewHolder {

        public TextView txtId;
        public TextView txtName;



        public ViewHolderDatos(@NonNull View itemView) {
            super(itemView);
            txtId = itemView.findViewById(R.id.idtxtid);
            txtName = itemView.findViewById(R.id.txtRecycler);


        }
    }//end ViewHolder

    public String Minkm(String distancia, String tiempo){
        //Pedir tiempo en minutos
        //Pedir distancia en metros


        double Distancia = Double.valueOf(distancia);
        double Tiempo = Double.valueOf(tiempo);
        double minkm = Distancia*1000*(1/Tiempo);
        String Minkm = String.valueOf(minkm);

        return Minkm;
    }//end Minkm

    public String Seckm(String distancia, String tiempo)
    {
       

        double Distancia = Double.valueOf(distancia);
        double Tiempo = Double.valueOf(tiempo)*60;
        double SecKm = Distancia*1000*(1/Tiempo);
        String seckm = String.valueOf(SecKm);
        return seckm;
    }
}//end Adapter
