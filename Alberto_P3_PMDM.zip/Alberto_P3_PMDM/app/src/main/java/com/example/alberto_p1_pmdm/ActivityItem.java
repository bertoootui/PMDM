package com.example.alberto_p1_pmdm;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ActivityItem extends AppCompatActivity {
    Entrenamiento entrenamiento = new Entrenamiento();
    ArrayList<Entrenamiento> listaEntrenamiento;
    RecyclerView recycler;
    RecyclerView.Adapter adaptador;
    TextView txtid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.itemlist);
        listaEntrenamiento = new ArrayList<>();
        Button btAdd = (Button) this.findViewById( R.id.butañadir );
        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityItem.this.onAdd();
            }
        });
        txtid = (TextView) this.findViewById(R.id.idtxtid);
        int id = Integer.parseInt(txtid.getText().toString());
        String distancia = String.valueOf(listaEntrenamiento.get(id).getDistancia());
        String tiempo = String.valueOf(listaEntrenamiento.get(id).getTiempo());
        String fecha = String.valueOf(listaEntrenamiento.get(id).getFecha());
        String minkm = String.valueOf(listaEntrenamiento.get(id).getMinkm());
        String seckm = String.valueOf(listaEntrenamiento.get(id).getSeckm());
        String vmedia = String.valueOf(listaEntrenamiento.get(id).getVelocidadmedia());

       TextView txtdistancia = (TextView) this.findViewById(R.id.txtdistancia);
        TextView  txttiempo = (TextView) this.findViewById(R.id.txttiempo);
        TextView  txtfecha = (TextView) this.findViewById(R.id.txtfecha);
        TextView  txtminkm = (TextView) this.findViewById(R.id.txtminkm);
        TextView  txtseckm = (TextView) this.findViewById(R.id.txtseckm);
        TextView  txtvmedia = (TextView) this.findViewById(R.id.txtmedia);

        txtdistancia.setText(distancia);
        txtfecha.setText(fecha);
        txtminkm.setText(minkm);
        txtseckm.setText(seckm);
        txttiempo.setText(tiempo);
        txtvmedia.setText(vmedia);






        adaptador = new Adapter(listaEntrenamiento);

        recycler.setAdapter(adaptador);


        //llenar ArrayList








    }

    private void onAdd() {


        AlertDialog.Builder builder = new AlertDialog.Builder( this );
        builder.setTitle("Añadir entrenamieto");


        View v = getLayoutInflater().inflate(R.layout.custom_alertdialog, null);
        builder.setView(v);
        final EditText txtfecha  = (EditText) v.findViewById(R.id.txtfecha);
        final EditText txttiempo = (EditText) v.findViewById(R.id.txtTiempo);
        final EditText txtdistancia = (EditText) v.findViewById(R.id.txtDistancia);
        txtid = (TextView) this.findViewById(R.id.idtxtid);
        final int id = Integer.parseInt(txtid.getText().toString());
        builder.setPositiveButton( "+", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                entrenamiento = new Entrenamiento();

                String fecha = txtfecha.getText().toString();
                SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                Date fechaDate = null;
                try {
                    fechaDate = formato.parse(fecha);
                }
                catch (ParseException ex) {
                    Toast t = Toast.makeText(getApplicationContext(), "Valor no válido",Toast.LENGTH_LONG);
                    t.show();
                    entrenamiento.setFecha(fechaDate);
                }


                String tiempo = txttiempo.getText().toString();
                Double tiempo2= Double.valueOf(tiempo);
                entrenamiento.setTiempo(tiempo2);


                String distancia = txtdistancia.getText().toString();
                Double disntacia2 = Double.valueOf(distancia);
                entrenamiento.setDistancia(disntacia2);
                listaEntrenamiento.add(id,entrenamiento);




            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.create().show();




    }
    
}
